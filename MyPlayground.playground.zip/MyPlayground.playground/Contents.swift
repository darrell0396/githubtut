//: Playground - noun: a place where people can play

import UIKit
import Cocoa

for var x = 0; x< 10; x++ {
    print(x)
}